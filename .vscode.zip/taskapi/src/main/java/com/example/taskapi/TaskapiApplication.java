package com.example.taskapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskapiApplication {
    public static void main(String[] args) {
        SpringApplication.run(TaskapiApplication.class, args);
    }
}